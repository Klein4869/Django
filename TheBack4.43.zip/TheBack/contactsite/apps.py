from django.apps import AppConfig


class ContactsiteConfig(AppConfig):
    name = 'contactsite'
