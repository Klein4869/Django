from django.apps import AppConfig


class IndexBackConfig(AppConfig):
    name = 'index_back'
